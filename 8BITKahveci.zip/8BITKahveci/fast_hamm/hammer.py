import multiprocessing
from scipy.spatial.distance import cdist
import timeit
import numpy as np


SIMILARITY = 0.2
PROCESSES = 8


class hamming_class:

    #initiliazing signature array
    def __init__(self,x):
        self.signatures = x


    #processing a simple thread
    def find_distance(self,left, right, newsign):
        a = cdist(self.signatures[left:right,:], newsign, 'hamming')

        for i in range(0, right-left-1):
            if a[i][0] <= SIMILARITY:
                print 'Similar image:'
                print self.signatures[i+left]



    #starting all 8 threads iteratively
    def process_starter(self, newsignature):

        n_items = self.signatures.size
        n_items /= 64   #finding the size of the signature array
        inc = n_items / PROCESSES #determining the increment magnitude

        i=0

        u = []
        while i < n_items:
            u.append(multiprocessing.Process(target=self.find_distance, args=(i, i+inc-1, newsignature)))
            i+=inc

        for j in range(0, PROCESSES):
            u[j].start()





