import timeit
import numpy as np
from fast_hamm import hammer
from pymongo import MongoClient
from random import randrange

ItemPerUser = np.load('ItemAmountPerUser.npy') #load all users' current photo count

inputImages = np.load('little.npy') #THE NPY FILE TO USE RANDOM SIGNATURES

todaysphotos = dict()  #the photos that are holt

DAYLIMIT =9999 #maximum number of photos per user and maximum number of signatures that are holt

global photoCount #the amount of photos of holt

def updateDBSOut():

    global photoCount

    print "Updating DBS Outside..."

    client = MongoClient()

    db = client.newDBS

    for key in todaysphotos: #iterate through the photos user_id by user_id

        thenpy = str(key)+'.npy'

        arr = np.load(thenpy) #take the stored photos of the user

        for i in range(0,len(todaysphotos[key])): #iterate through all holt photos of the user

            db.newDBS.insert_one({'photo': arr[0].tolist(), 'user_id': key}) #insert the old photos of the user

            arr = np.delete(arr, 0 ,axis = 0) #delete the photo that is added to db

            arr = np.vstack([ arr, todaysphotos[key][i]]) #add the current holt photo to the array


    todaysphotos.clear() #clear all the holt photos

    photoCount = 0 #zero the number

    print 'Written into dbs outside'

    return



inn = input('Enter a photo?: ')

photoCount = 0

while(inn == 1):

        u_id = input('Enter user_id ')

        inPhoto = inputImages[randrange(0,99)][None,:]

        f1 = timeit.default_timer()


        if ItemPerUser[u_id] == 0: # the new user case

            signs = str(u_id)

            k = np.zeros([10000,64], dtype='bool') #create array for the new user

            k[0] = inPhoto

            ItemPerUser[u_id] = 1 #update number of photos belong to him

            np.save(signs , k) #store photos

        elif ItemPerUser[u_id] >=1 and ItemPerUser[u_id] < DAYLIMIT: #user with less than 10000 photos

            signs = str(u_id) + '.npy'

            k = np.load(signs)

            a = hammer.hamming_class(k)

            a.process_starter(inPhoto) #search the photo

            k[int(ItemPerUser[u_id]+1)] = inPhoto #add the photo to the array

            ItemPerUser[u_id] += 1 #update number of photos belong to him

            np.save(str(u_id), k) #store the photos

        else: #user with 10000 photos

            signs = str(u_id) + '.npy'

            k = np.load(signs)

            a = hammer.hamming_class(k)

            a.process_starter(inPhoto)

            if u_id in todaysphotos: #if the user had some photos today already
                todaysphotos[u_id].append(inPhoto)
            else: #it's his first photo today that is more than 5
                todaysphotos[u_id] = [inPhoto]


            photoCount += 1 #update photocount

            if photoCount >= DAYLIMIT:

                updateDBSOut()



        print timeit.default_timer()-f1

        inn = input('Continue?: ')

np.save("ItemAmountPerUser" , ItemPerUser) #update the value of photos stored per user